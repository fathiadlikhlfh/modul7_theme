package com.example.material_design_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
